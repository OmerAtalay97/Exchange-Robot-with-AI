BINANCE_API_KEY = 'yourbinanceapikey'
BINANCE_SECRET_KEY = 'yourbinancesecretkey'