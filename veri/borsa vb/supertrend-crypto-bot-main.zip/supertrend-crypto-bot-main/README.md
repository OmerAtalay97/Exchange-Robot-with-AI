# supertrend-crypto-bot

supertrend bot using python, pandas, and ccxt

## Demo Video and Instructions:

* https://youtube.com/parttimelarry
* https://www.youtube.com/watch?v=1PEyddA1y5E

# Like this? Buy Me a Coffee!

https://buymeacoffee.com/parttimelarry