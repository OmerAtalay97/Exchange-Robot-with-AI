# lstm_test

Time Series Prediction with LSTM

DATA 

FOREX DATA with followings

Folder name is sampling rate

 M1 : 1 min data with currency pair
 M5 : 5 min data with currency pair
 
 
 The target of the code is to predict future value of currency pair by using previous data. 
 Assumed the future value is defined by the previous values
 
 All the process will be on the Frequency Domain,
 
 We assume that the frequency component of each time frame has long/short time effect to future values
 Then the question becomes, "is there a way to learn this pattern to predict future values with acceptable certainty"
 
 
 We will work on historic data only.

 
 Simulation is the main program and please refer to explanation of each parameters
 
 We will use following params; phase, sum of imag and real part.  
